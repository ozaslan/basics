<map version="0.9.0_Beta_8" background_color="#ffffff">
<!-- To view this file, download free mind mapping software FreeMind from http://freemind.sourceforge.net -->
<node CREATED="1185522662655" ID="Freemind_Link_697017692" MODIFIED="1185522662655" TEXT="New Mindmap">
<node BACKGROUND_COLOR="#ffff00" CREATED="1180440171456" HGAP="13" ID="Freemind_Link_1536550240" MODIFIED="1185522671080" POSITION="right" TEXT="icp" VSHIFT="-71">
<node BACKGROUND_COLOR="#ffff00" CREATED="1181117607993" ID="Freemind_Link_1092514301" MODIFIED="1181117725197" TEXT="sm_icp_animation">
<node BACKGROUND_COLOR="#ffff00" CREATED="1180597650306" ID="Freemind_Link_771510588" MODIFIED="1180605225798" TEXT="fare demo carina con animation"/>
<node BACKGROUND_COLOR="#ffff00" CREATED="1181117621181" ID="Freemind_Link_755242794" MODIFIED="1181117705322" TEXT="creare default configurations (many_points)"/>
</node>
<node BACKGROUND_COLOR="#ffff00" CREATED="1181117849182" ID="Freemind_Link_305830794" MODIFIED="1181117852985" TEXT="formati">
<node BACKGROUND_COLOR="#ffff00" CREATED="1180735952196" ID="Freemind_Link_770251969" MODIFIED="1180735957333" TEXT="togliere theta da json"/>
</node>
<node BACKGROUND_COLOR="#ffff00" CREATED="1181117858778" ID="Freemind_Link_1547450624" MODIFIED="1181117861394" TEXT="libcsm">
<node BACKGROUND_COLOR="#ffff00" CREATED="1180772534386" ID="Freemind_Link_82493141" MODIFIED="1180772537900" TEXT="output CARMEN">
<node BACKGROUND_COLOR="#ffff00" CREATED="1180772538326" ID="Freemind_Link_1186113497" MODIFIED="1180772543140" TEXT="opzione output_format"/>
</node>
<node BACKGROUND_COLOR="#ffff00" CREATED="1180520218191" ID="Freemind_Link_1659736302" MODIFIED="1180520224162" TEXT="cambiare nomi maxPerc e *Deg"/>
<node BACKGROUND_COLOR="#ffff00" CREATED="1180519409707" ID="Freemind_Link_1896482752" MODIFIED="1180519416420" TEXT="fare check memoria con valgrind"/>
<node BACKGROUND_COLOR="#ffff00" CREATED="1180520392227" ID="Freemind_Link_1281566208" MODIFIED="1180520396890" TEXT="togliere assert da journal"/>
<node BACKGROUND_COLOR="#ffff00" CREATED="1180520568815" ID="Freemind_Link_150033155" MODIFIED="1180520575765" TEXT="opzioni set in options">
<node BACKGROUND_COLOR="#ffff00" CREATED="1180809994085" ID="Freemind_Link_648038378" MODIFIED="1180810000814" TEXT="quoted strings"/>
</node>
<node BACKGROUND_COLOR="#ffff00" CREATED="1180448230938" ID="Freemind_Link_442257989" MODIFIED="1180448237104" TEXT="mettere misc_apps di l&#xe0;"/>
<node BACKGROUND_COLOR="#ffff00" CREATED="1180440303009" ID="Freemind_Link_1454958561" MODIFIED="1180440309734" TEXT="sei sicuro della precisione json?"/>
<node BACKGROUND_COLOR="#ffff00" CREATED="1181889593162" ID="Freemind_Link_1035409220" MODIFIED="1181889629303" TEXT="isnan con fast-math"/>
</node>
<node BACKGROUND_COLOR="#ffff00" CREATED="1181117893258" ID="Freemind_Link_942437306" MODIFIED="1181117895596" TEXT="raytracer">
<node BACKGROUND_COLOR="#ffff00" CREATED="1180776125485" ID="Freemind_Link_391369505" MODIFIED="1180776136422" TEXT="fare raytracer che legge le pose da file (non da cin)"/>
<node BACKGROUND_COLOR="#ffff00" CREATED="1180440764465" ID="Freemind_Link_368708750" MODIFIED="1180440770287" TEXT="fare raytracing circles"/>
<node BACKGROUND_COLOR="#ffff00" CREATED="1180775902928" ID="Freemind_Link_732352514" MODIFIED="1180775916533" TEXT="fare FIG.read(FILE*) e cambiare &quot;raytracer.cpp&quot;"/>
<node BACKGROUND_COLOR="#ffff00" CREATED="1181656906861" ID="Freemind_Link_411765945" MODIFIED="1181656912316" TEXT="aggiungere real-cluster"/>
</node>
<node BACKGROUND_COLOR="#ffff00" CREATED="1181117946781" ID="Freemind_Link_39490840" MODIFIED="1181117950748" TEXT="esperimenti">
<node BACKGROUND_COLOR="#ffff00" CREATED="1180451745014" ID="Freemind_Link_514348022" MODIFIED="1180451751115" TEXT="disegnare altri ambienti"/>
<node BACKGROUND_COLOR="#ffff00" CREATED="1181118007333" ID="Freemind_Link_1940417774" MODIFIED="1181118012234" TEXT="rimetti a posto esperimenti"/>
</node>
</node>
</node>
</map>
