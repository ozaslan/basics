 require 'point2line'
include MathUtils
 test_gm2
