require 'rsm_mathutils'


module Pose 

	
end


