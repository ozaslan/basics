#require 'gsl'

require 'rsm_journal'
require 'rsm_mathutils'
require 'rsm_misc'
require 'rsm_orientation'
require 'rsm_laserdata'
require 'rsm_laserdata_ops'
require 'rsm_gpm'
require 'rsm_gpmicp'
require 'rsm_icp'

