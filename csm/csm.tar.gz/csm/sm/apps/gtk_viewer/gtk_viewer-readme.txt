
# GTK Viewer #

Just an experiment.

Software prerequisites:

* a recent version of GTK 
* GooCanvas: http://sourceforge.net/projects/goocanvas

