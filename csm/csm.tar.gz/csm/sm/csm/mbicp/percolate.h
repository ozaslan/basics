
#ifndef percolate
#define percolate

#include "MbICP2.h"
#include "TData.h"

#ifdef __cplusplus
extern "C" {
#endif

void heapsort(TAsoc a[], int n);

#ifdef __cplusplus
}
#endif

#endif
